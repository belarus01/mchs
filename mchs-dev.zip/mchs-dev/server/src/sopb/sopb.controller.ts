import { Controller } from '@nestjs/common';

@Controller('sopb')
export class SopbController {}
