export interface CreateUserGroupDTO{
    idGroup: number;
    uid: number;
}