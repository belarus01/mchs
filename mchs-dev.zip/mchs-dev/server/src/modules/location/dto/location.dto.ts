export interface LocationDTO{
    uid?:number;
    latitude?:string;
    longitude?:string;
    dateRecord?:string;
}