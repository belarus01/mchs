export enum ROLES {
    User = 4,
    Сhief = 3,
    Admin = 2,
    Syperadmin = 1
  }