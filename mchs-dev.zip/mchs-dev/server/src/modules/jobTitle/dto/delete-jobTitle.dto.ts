export interface DeleteJobTitleDTO{
    idDeptJob: number;
    uid: number;
}