export interface CreateJobTitleDTO{
    job: string;//comment: "Наименование должности"
    org: number;//пожарные/надзор

}