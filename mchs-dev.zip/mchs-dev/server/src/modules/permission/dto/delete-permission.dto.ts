export interface DeletePermissionDTO{
    idPerm: number;
    uid: number;
}