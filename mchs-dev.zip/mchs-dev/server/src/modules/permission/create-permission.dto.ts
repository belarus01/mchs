export interface CreatePermissionDTO{
    namePerm: string;
    org: number;
    idUserType: number;
    uid: number;
}