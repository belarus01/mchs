export interface CreateEventOrderDTO{
    idEvent: number;
    org: number;
    uid: number;
    postTitle: string;
    fioPostTitle: string;
    postAgent: string;
    nameAgent: string;
}