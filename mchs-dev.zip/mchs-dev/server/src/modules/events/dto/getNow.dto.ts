export interface GetNowDTO{
    dateNow: Date;
}