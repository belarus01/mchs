export interface DeleteUserDTO{
    uid: number;
    adminUid: number;
}