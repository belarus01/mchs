export interface CreateGroupDTO{
    name: string;
    idDept?: number;
    uid?: number;
}