import { User } from "src/modules/users/user.entity";

export interface DeleteGroupDTO{
    idGroup: number,
    uid: number,

}