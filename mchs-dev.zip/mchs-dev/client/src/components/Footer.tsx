import React from "react";
export const Footer = () => (
    <footer className="bg-white shadow-large py-3 flex items-center justify-center">
      
      <p className="text-center">&copy; АПК КНО 2022</p>
    </footer>
  );